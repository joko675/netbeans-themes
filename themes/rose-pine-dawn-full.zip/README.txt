Rosé Pine Dawn for Apache NetBeans 31
=====================================
Motyw jasny oparty o oficjalna palete Rose Pine (https://rosepinetheme.com/palette/).
Profil kolorow w NetBeans: Rose_Pine_Dawn

Zawartosc
---------
- config\Editors\FontsColors\Rose_Pine_Dawn\
      kolory tokenow i podswietlen edytora
- config\Editors\text\x-java\FontsColors\Rose_Pine_Dawn\
      kolory tokenow Java (klasy, metody, adnotacje, Javadoc)
- config\LookAndFeel\FlatLightLaf.properties
      paleta interfejsu (FlatLaf Light)
- config\.nbattrs
      ustawia Rose_Pine_Dawn jako aktywny profil

Paleta
------
Base            #faf4ed    Surface         #fffaf3    Overlay         #f2e9e1
Muted           #9893a5    Subtle          #797593    Text            #464261
Love            #b4637a    Gold            #ea9d34    Rose            #d7827e
Pine            #286983    Foam            #56949f    Iris            #907aa9
Highlight Low   #f4ede8    Highlight Med   #dfdad9    Highlight High  #cecacd

Role kolorow
------------
tlo edytora      Base          komentarze     Muted (kursywa)
tekst            Text          slowa kluczowe Pine
lancuchy         Gold          liczby         Rose
metody           Rose          pola/typy      Foam
parametry        Iris          adnotacje      Iris (kursywa)
atrybuty HTML    Iris          zaznaczenie    Highlight Med

Instalacja
----------
1. Zamknij NetBeans.
2. Zrob kopie zapasowa katalogu %APPDATA%\NetBeans\31\config
3. Skopiuj katalog "config" z tego archiwum do %APPDATA%\NetBeans\31\
   (pozwol nadpisac istniejace pliki).
4. Uruchom NetBeans.
   Tools > Options > Fonts & Colors > Profile = Rose_Pine_Dawn
   Tools > Options > Appearance > Look and Feel = FlatLaf Light

Uwaga: plik FlatLightLaf.properties jest wspolny dla calego IDE, wiec podmienia palete
interfejsu. Aby wrocic do poprzedniego wygladu, przywroc kopie zapasowa config.

Mozesz zainstalowac wszystkie trzy warianty (Rose_Pine, Rose_Pine_Moon,
Rose_Pine_Dawn) - kazdy ma wlasny folder profilu, wiec nie koliduja.
Ostatnio skopiowany ZIP ustawia tylko swoj profil jako aktywny; przelaczasz go
w Tools > Options > Fonts & Colors > Profile.

Czcionka: Consolas 14 (do zmiany w Options > Fonts & Colors > Rose_Pine_Dawn).
