Rosé Pine for Apache NetBeans 31
================================
Motyw ciemny oparty o oficjalna palete Rose Pine (https://rosepinetheme.com/palette/).
Profil kolorow w NetBeans: Rose_Pine

Zawartosc
---------
- config\Editors\FontsColors\Rose_Pine\
      kolory tokenow i podswietlen edytora
- config\Editors\text\x-java\FontsColors\Rose_Pine\
      kolory tokenow Java (klasy, metody, adnotacje, Javadoc)
- config\LookAndFeel\FlatDarkLaf.properties
      paleta interfejsu (FlatLaf Dark)
- config\.nbattrs
      ustawia Rose_Pine jako aktywny profil

Paleta
------
Base            #191724    Surface         #1f1d2e    Overlay         #26233a
Muted           #6e6a86    Subtle          #908caa    Text            #e0def4
Love            #eb6f92    Gold            #f6c177    Rose            #ebbcba
Pine            #31748f    Foam            #9ccfd8    Iris            #c4a7e7
Highlight Low   #21202e    Highlight Med   #403d52    Highlight High  #524f67

Role kolorow
------------
tlo edytora      Base          komentarze     Muted (kursywa)
tekst            Text          slowa kluczowe Pine
lancuchy         Gold          liczby         Rose
metody           Rose          pola/typy      Foam
parametry        Iris          adnotacje      Iris (kursywa)
atrybuty HTML    Iris          zaznaczenie    Highlight Med

Instalacja
----------
1. Zamknij NetBeans.
2. Zrob kopie zapasowa katalogu %APPDATA%\NetBeans\31\config
3. Skopiuj katalog "config" z tego archiwum do %APPDATA%\NetBeans\31\
   (pozwol nadpisac istniejace pliki).
4. Uruchom NetBeans.
   Tools > Options > Fonts & Colors > Profile = Rose_Pine
   Tools > Options > Appearance > Look and Feel = FlatLaf Dark

Uwaga: plik FlatDarkLaf.properties jest wspolny dla calego IDE, wiec podmienia palete
interfejsu. Aby wrocic do poprzedniego wygladu, przywroc kopie zapasowa config.

Mozesz zainstalowac wszystkie trzy warianty (Rose_Pine, Rose_Pine_Moon,
Rose_Pine_Dawn) - kazdy ma wlasny folder profilu, wiec nie koliduja.
Ostatnio skopiowany ZIP ustawia tylko swoj profil jako aktywny; przelaczasz go
w Tools > Options > Fonts & Colors > Profile.

Czcionka: Consolas 14 (do zmiany w Options > Fonts & Colors > Rose_Pine).
